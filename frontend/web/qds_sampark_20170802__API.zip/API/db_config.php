<?php
mysql_connect("localhost","qdegrees_sampark","admin@123");
mysql_select_db("qdegrees_qds_sampark");
date_default_timezone_set('Asia/Calcutta');
$today = date("F j, Y, g:i a");

?>