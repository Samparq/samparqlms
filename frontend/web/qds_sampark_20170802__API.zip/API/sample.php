<?php
echo file_put_contents("test.txt","Hello World. Testing!");
?> 