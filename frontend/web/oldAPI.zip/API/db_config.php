<?php
mysql_connect("localhost","root","admin@123");
mysql_select_db("qds_samparq");
date_default_timezone_set('Asia/Calcutta');
$today = date("F j, Y, g:i a");

?>